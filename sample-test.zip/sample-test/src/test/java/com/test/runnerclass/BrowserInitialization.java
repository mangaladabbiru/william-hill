package com.test.runnerclass;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class BrowserInitialization {
	
	public static  WebDriver driver = null;
	public WebDriver initializeDriver(WebDriver driver) {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Mangala\\workspace\\william\\sample-test\\src\\test\\drivers\\chromedriver2.35.exe");
		DesiredCapabilities capability = new DesiredCapabilities();

		driver = new ChromeDriver(capability);
		
		
		return driver;
	}

}
