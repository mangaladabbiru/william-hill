package com.test.runnerclass;


import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

/**
 * Created by 892467 on 4/06/2016.
 */

@RunWith(Cucumber.class)
@CucumberOptions(format = {"pretty", "html:target/cucumber-pretty", "json:target/cucumber.json"},
        features = {"src/test/resource"},
        glue = {"com/test/steps"},
        tags = {"@test"})

public class RunnerClass {

}
