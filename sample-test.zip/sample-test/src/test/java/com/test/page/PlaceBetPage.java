package com.test.page;

import static org.junit.Assert.assertTrue;

import org.openqa.selenium.By;
//import org.openqa.selenium.support.FindBy;
//import org.openqa.selenium.WebElement;


//import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.FindBy;



//import com.test.*;
import com.test.steps.PlaceBetSteps;

public class PlaceBetPage {
	
	/*@FindBy(css = "button[class='Button_button_1Hw Tabs_tab_3Qb'][type='button']") 
	public static WebElement searchField;
	public static WebDriver wdriver;
	
	public PlaceBetPage(WebDriver driver){
		
		this.wdriver = driver;
	}*/
	
	//PageObject Global Declaration
	public WebElement BetType;
	public WebElement BetOption;
	public WebElement Stake;
	public WebElement BetSlip;
	public WebElement BetSlipCart;
	public WebElement PlaceBets;
	
	public void verifyTitlePagePresent(){
		// Verify if Title page contains William Hill - Assertion
		assertTrue(PlaceBetSteps.driver.getTitle().contains("William Hill"));
	}
	
	public void selectBetType(){
		// Select Bet Type as Racing
		BetType = PlaceBetSteps.driver.findElement(By.cssSelector("button[class='Button_button_1Hw Tabs_tab_3Qb'][type='button']"));
		BetType.click();
	}
	
	public void selectBetOption(){
		// Select one option among available Racing options
		BetOption = PlaceBetSteps.driver.findElement(By.cssSelector("div[class='TrendingBets_betButtonWrapper_2nI']"));
		BetOption.click();
	}
	
	public void selectStake(){
		//Select Stake as 10.5
		Stake = PlaceBetSteps.driver.findElement(By.cssSelector("input[class='CurrencyBox_currencyBox_b0O CurrencyBox_withoutSymbol_87M QuickBetOptions_textInput_3JR'][type='text']"));
		Stake.sendKeys("10.5");
	}
	
	public void addtoBetSlip(){
		// Add to Bet Slip
		BetSlip = PlaceBetSteps.driver.findElement(By.cssSelector("button[class='Button_button_1Hw Button_color_28N Button_transparent_31s'][type='button']"));
		BetSlip.click();
	}

	public void clickBetSlipCart(){
		// Click Bet Slip
		BetSlipCart = PlaceBetSteps.driver.findElement(By.cssSelector("button[class='Button_button_1Hw SideBar_button_Hgk SideBar_buttonSelected_3Rx'][type='button']"));
		BetSlipCart.click();
	}
	
	public void clickPlaceBets(){
		// Place Bets
		PlaceBets = PlaceBetSteps.driver.findElement(By.cssSelector("button[class='Button_button_1Hw Button_color_28N Button_green_3Ux Betslip_placeBets_3xf'][type='button']"));
		PlaceBets.click();
	}
	
	public void verifyWelcomePagePresent(){
		// Verify if user is redirected to Login Page after successfully placing bets
		assertTrue(PlaceBetSteps.driver.getPageSource().contains("Welcome back"));
	}

}
