package com.test.steps;

import java.util.concurrent.TimeUnit;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.And;

import org.openqa.selenium.WebDriver;

import com.test.page.*;
import com.test.runnerclass.BrowserInitialization;

public class PlaceBetSteps {

	public static WebDriver driver;
	
	public PlaceBetSteps() {
		
		if (BrowserInitialization.driver == null) {
			BrowserInitialization br = new BrowserInitialization();
			driver = br.initializeDriver(driver);
		}else {
			
			driver = BrowserInitialization.driver;
		}
		
	}

	@Given("^I navigate to William Hills website$")
	public void launchBrowser() {		
	    //  Wait For Page To Load by putting Implicit wait
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		// Navigate to URL
		driver.get("https://www.williamhill.com.au/");		
		// Maximize the window
		driver.manage().window().maximize();		
		PlaceBetPage pbp = new PlaceBetPage();
		pbp.verifyTitlePagePresent();
	}

	@When("^I select bet type as racing$")
	public void betType()throws Exception {
		PlaceBetPage pbp = new PlaceBetPage();
		pbp.selectBetType();
	}

	@And("^I select one option$")
	public void betOption()throws Exception {
		PlaceBetPage pbp = new PlaceBetPage();
		pbp.selectBetOption();
	}
	
	@And("^I select stake as 10.5$")
	public void stake()throws Exception {
		PlaceBetPage pbp = new PlaceBetPage();
		pbp.selectStake();
	}
	
	@And("^I select add to bet slip$")
	public void betSlip()throws Exception {
		PlaceBetPage pbp = new PlaceBetPage();
		pbp.addtoBetSlip();
	}

	@Then("^I see selection added to Bet slip Cart$")
	public void placeBets() {
		PlaceBetPage pbp = new PlaceBetPage();
		pbp.clickBetSlipCart();
		pbp.clickPlaceBets();
		pbp.verifyWelcomePagePresent();
	}
}
